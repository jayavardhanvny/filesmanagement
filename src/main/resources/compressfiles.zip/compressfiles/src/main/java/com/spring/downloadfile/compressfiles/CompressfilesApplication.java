package com.spring.downloadfile.compressfiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompressfilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompressfilesApplication.class, args);
	}

}
